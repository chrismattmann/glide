//IXMLConversion.java
package Prism.extensions.conn;


public interface IXMLConversion 
{
}
