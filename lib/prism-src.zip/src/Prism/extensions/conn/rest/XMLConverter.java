//XMLConverter.java
package Prism.extensions.conn;


public class XMLConverter implements IXMLConversion 
{
   
   /**
    * @roseuid 3D8A01D60115
    */
   public XMLConverter() 
   {
    
   }
}
