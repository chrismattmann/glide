//IConnDeliveryGuarantees.java
package Prism.extensions.conn;


public interface IConnDeliveryGuarantees 
{
}
