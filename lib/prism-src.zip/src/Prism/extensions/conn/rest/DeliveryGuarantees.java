//DeliveryGuarantees.java
package Prism.extensions.conn;


public class DeliveryGuarantees implements IConnDeliveryGuarantees 
{
   
   /**
    * @roseuid 3D8A01D50308
    */
   public DeliveryGuarantees() 
   {
    
   }
}
