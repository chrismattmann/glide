package Prism.extensions.port.distribution;

/**
 * a placeholder interface for Infrared distribution.
 * 
 *@version 2.0
 *@author USC Soft. Arch. Group. Contact: Sam Malek <A HREF="mailto:malek@usc.edu"> malek@usc.edu </A>
 */

public abstract class IRDistribution extends AbstractDistribution
{
   public IRDistribution()
   {
    
   }
}
